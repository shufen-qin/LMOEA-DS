%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
The code is written by Shufen Qin. 

 You can run directly "LMOEA_DS_run.m".


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%